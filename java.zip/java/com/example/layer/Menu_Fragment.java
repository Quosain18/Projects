package com.example.layer;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView; // For TextView
import android.widget.Button; // For Button
import android.widget.Toast;

public class Menu_Fragment extends Fragment {

    // Declare TextView, Button, and counter variables
    private TextView textView;
    private Button plusButton;
    private Button minusButton;
    private Button bill;
    private int counter = 0;
    private ImageView image;

    public Menu_Fragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_menu_, container, false);

        // Find references to the TextView and Buttons
        textView = rootView.findViewById(R.id.counter);
        plusButton = rootView.findViewById(R.id.plus);
        minusButton = rootView.findViewById(R.id.minus);
        image = rootView.findViewById(R.id.first_image);
        bill = rootView.findViewById(R.id.add_cart);

        textView = rootView.findViewById(R.id.counters);
        plusButton = rootView.findViewById(R.id.plus_ONE);
        minusButton = rootView.findViewById(R.id.minus_one);
        image = rootView.findViewById(R.id.second_image);
        bill = rootView.findViewById(R.id.add_carts);

        textView = rootView.findViewById(R.id.counter_two);
        plusButton = rootView.findViewById(R.id.plus_two);
        minusButton = rootView.findViewById(R.id.minus_two);
        image = rootView.findViewById(R.id.third_image);
        bill = rootView.findViewById(R.id.add_cart_two);

        textView = rootView.findViewById(R.id.counter_three);
        plusButton = rootView.findViewById(R.id.plus_three);
        minusButton = rootView.findViewById(R.id.minus_three);
        image = rootView.findViewById(R.id.fourth_image);
        bill = rootView.findViewById(R.id.add_cart_three);

        textView = rootView.findViewById(R.id.counter_four);
        plusButton = rootView.findViewById(R.id.plus_four);
        minusButton = rootView.findViewById(R.id.minus_four);
        image = rootView.findViewById(R.id.fifth_image);
        bill = rootView.findViewById(R.id.add_cart_four);

        textView = rootView.findViewById(R.id.counter_five);
        plusButton = rootView.findViewById(R.id.plus_five);
        minusButton = rootView.findViewById(R.id.minus_five);
        image = rootView.findViewById(R.id.sixth_image);
        bill = rootView.findViewById(R.id.add_cart_five);
        // Set OnClickListener for the plus Button
        plusButton.setOnClickListener(v -> {
            counter++;
            textView.setText(String.valueOf(counter));
        });

        // Set OnClickListener for the minus Button
        minusButton.setOnClickListener(v -> {
            if (counter > 0) {
                counter--;
            }
            textView.setText(String.valueOf(counter));
        });

        // Set OnClickListener for the bill Button
        bill.setOnClickListener(v -> {
            if (counter > 0) {
                // Create a Bundle to pass data to the next Fragment
                Bundle bundle = new Bundle();
                bundle.putString("textViewValue", textView.getText().toString());
                bundle.putInt("image", R.drawable.one_image); // Assuming first_image is the resource ID of the image

                // Create an instance of the next Fragment
                BillFragment nextFragment = new BillFragment();
                nextFragment.setArguments(bundle);

                // Perform the fragment transaction
                getFragmentManager().beginTransaction().replace(R.id.container, nextFragment)
                        .addToBackStack(null)
                        .commit();
            } else {
                // Show a toast message indicating the cart is empty
                Toast.makeText(getContext(), "Please add items to the cart", Toast.LENGTH_SHORT).show();
            }
        });

        return rootView;
    }
}
