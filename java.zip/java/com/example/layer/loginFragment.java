package com.example.layer;


import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class loginFragment extends Fragment {

    Button register;

    public loginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login2, container, false);

        // Initialize the button
        register= view.findViewById(R.id.register);

        // Set the click listener using lambda expression
        register.setOnClickListener(v -> {
            // Create an instance of the signupFragment
            AFragment aFragment = new AFragment();

            // Perform the fragment transaction
            FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.container, aFragment); // Replace with your container ID
            fragmentTransaction.addToBackStack(null); // Optional: to add the transaction to the back stack
            fragmentTransaction.commit();
        });

        return view;
    }
}